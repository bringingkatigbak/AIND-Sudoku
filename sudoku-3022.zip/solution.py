from utils import *
#from sets import Set

assignments = []

def assign_value(values, box, value):
    """
    Please use this function to update your values dictionary!
    Assigns a value to a given box. If it updates the board record it.
    """

    # Don't waste memory appending actions that don't actually change any values
    if values[box] == value:
        return values

    values[box] = value
    if len(value) == 1:
        assignments.append(values.copy())
    return values

def naked_twins(values, assign_value = assign_value):
    """Eliminate values using the naked twins strategy.
    Args:
        values(dict): a dictionary of the form {'box_name': '123456789', ...}

    Returns:
        the values dictionary with the naked twins eliminated from peers.
    """

    # Find all instances of naked twins
    # Eliminate the naked twins as possibilities for their peers
    
    for unit in unitlist:
        seen = set()
        twins = set()
        twinParts = set()
        for pos in unit:
            cur = values[pos]
            if len(cur) == 2 and cur in seen:
                twins.add(cur)
                for char in cur:
                    twinParts.add(char)
                continue
            seen.add(cur)
        if len(twinParts) > 0:
            for pos in unit:
                if values[pos] not in twins:
                    for x in twinParts:
                        assign_value(values, pos, values[pos].replace(x, ""))
    return values

def search(values, assign_value):
    # First, reduce the puzzle using the previous function
    values = reduce_puzzle(values, naked_twins, assign_value)
    if values == False:
        return False
    
    # Choose one of the unfilled squares with the fewest possibilities
    MIN = 10
    MINPOS = "ZZ"
    for pos in values:
        if( len(values[pos]) > 1 and len(values[pos]) < MIN):
            MINPOS = pos
            MIN = len(values[pos])
            
    if MINPOS == "ZZ":
        return values
        
    # Now use recursion to solve each one of the resulting sudokus, and if one returns a value (not False), return that answer!
    choices = values[MINPOS]
    for choice in choices:
        myValues = {pos:values[pos] if pos != MINPOS else choice for pos in values}
        found = search(myValues, assign_value)
        if found != False:
            return found
    return False

def solve(grid, assign_value = assign_value):
    """
    Find the solution to a Sudoku grid.
    Args:
        grid(string): a string representing a sudoku grid.
            Example: '2.............62....1....7...6..8...3...9...7...6..4...4....8....52.............3'
    Returns:
        The dictionary representation of the final sudoku grid. False if no solution exists.
    """
    return search(grid_values(grid), assign_value)

if __name__ == '__main__':
    diag_sudoku_grid = '2.............62....1....7...6..8...3...9...7...6..4...4....8....52.............3'
    display(solve(diag_sudoku_grid, assign_value))

    try:
        from visualize import visualize_assignments
        visualize_assignments(assignments)

    except SystemExit:
        pass
    except:
        print('We could not visualize your board due to a pygame issue. Not a problem! It is not a requirement.')
